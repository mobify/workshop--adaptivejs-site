'use strict';

var grunt = require('grunt');
var saveCredentials = require('../lib/save-credentials');
var settingsPath = 'test/fixtures/tmpCreds';

exports.login = {
    saveCredentials: function(test) {

        var username = 'user@mobify.com';
        var key = 'asdf1234';

        if(grunt.file.isFile(settingsPath)) {
            grunt.file.delete(settingsPath);
        }

        saveCredentials(username, key, settingsPath);

        var creds = grunt.file.readJSON(settingsPath);

        test.equal(creds.username, username);
        test.equal(creds.api_key, key);

        // Cleanup
        grunt.file.delete(settingsPath);
        test.done();
    }
};
