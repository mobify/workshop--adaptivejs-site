'use strict';

var grunt = require('grunt');
var Utils = require('../lib/utils');

/*
  ======== A Handy Little Nodeunit Reference ========
  https://github.com/caolan/nodeunit

  Test methods:
    test.expect(numAssertions)
    test.done()
  Test assertions:
    test.ok(value, [message])
    test.equal(actual, expected, [message])
    test.notEqual(actual, expected, [message])
    test.deepEqual(actual, expected, [message])
    test.notDeepEqual(actual, expected, [message])
    test.strictEqual(actual, expected, [message])
    test.notStrictEqual(actual, expected, [message])
    test.throws(block, [error], [message])
    test.doesNotThrow(block, [error], [message])
    test.ifError(value)
*/

exports.verifyDependencies = {
    createBundle: function(test) {
        var files = ['test/fixtures/build.txt'];
        var archivePath = './tmp.tar';
        var projectSlug = 'test-project';
        var expectedOutput = 'bld/fixtures/build.txt';

        function removeTar() {
            grunt.util.spawn({
                cmd: 'rm',
                args: [archivePath]
            }, function done(err, result) {
                if (err) {
                    throw err;
                }
                else {
                    test.done();
                }
            });
        }

        function checkArchiveContents() {
            test.equal(grunt.file.isFile(archivePath), true);

            // Check that the tar contains the right file.
            grunt.util.spawn({
                cmd: 'tar',
                args: ['-tf', archivePath],
            }, function done(err, result) {
                test.ok(result.stdout.indexOf(expectedOutput) > -1);
                removeTar();
            });
        }

        Utils.createBundle(files, projectSlug, archivePath, checkArchiveContents);
    },

    readCredentials: function(test) {
        var creds = Utils.readCredentials('test/fixtures/creds');

        test.equal(creds, 'user@mobify.com:asdf1234');

        test.done();
    },

    buildObject: function (test) {
        var filepath = 'test/fixtures/test.zip';
        var testMessage = 'test message';

        var buildObject = Utils.buildObject(filepath, testMessage);

        var testFile = grunt.file.read(filepath, {encoding: null});
        var base64data = testFile.toString('base64');

        var testObj = {
            message: testMessage,
            encoding: "base64",
            data: base64data
        };

        test.deepEqual(testObj, buildObject);

        test.done();
    },

    getProjectApiPath: function(test) {
        var expected =
            'https://cloud.mobify.com/api/projects/some-project/do/things/';
        var actual = Utils.getProjectApiPath(
            'https://cloud.mobify.com/', 'some-project', '/do/things'
        );
        test.equal(expected, actual, 'It should add a trailing slash');

        var expected =
            'http://cloud.mobify.com/api/projects/a-project/do/things/';
        var actual = Utils.getProjectApiPath(
            'http://cloud.mobify.com', 'a-project', 'do/things/'
        );
        test.equal(actual, expected, 'It should keep a trailing slash');

        var expected =
            'http://cloud.mobify.com/api/projects/a-project/somepath/mytarget/';
        var actual = Utils.getProjectApiPath(
            'http://cloud.mobify.com', 'a-project', 'somepath', 'mytarget'
        );
        test.equal(actual, expected, 'It should add the target correctly');

        test.done();
    },

    getRequestHeaders: function(test) {
        var USER_AGENT_REGEX = /grunt-mobify#\d+\.\d+\.\d+/;

        var headers = Utils.getRequestHeaders();
        test.ok(headers['User-Agent']);
        test.ok(headers['User-Agent'].match(USER_AGENT_REGEX));

        var headers = Utils.getRequestHeaders({
            'Content-Length': '2048',
            'X-Random': 'Unicorns'
        });
        test.ok(headers['User-Agent']);
        test.ok(headers['User-Agent'].match(USER_AGENT_REGEX));
        test.equal(headers['Content-Length'], '2048');
        test.equal(headers['X-Random'], 'Unicorns');

        test.done();
    },

    throwForStatus: function(test) {
        test.doesNotThrow(function() {
            Utils.throwForStatus({statusCode: 200});
        });

        test.doesNotThrow(function() {
            Utils.throwForStatus({statusCode: 302});
        });

        test.throws(function() {
            Utils.throwForStatus({statusCode: 401});
        });

        test.throws(function() {
            Utils.throwForStatus({statusCode: 404});
        });

        test.throws(function() {
            Utils.throwForStatus({statusCode: 500});
        });

        test.done();
    },

    buildRequest: function(test) {
        var opts = {
            origin: 'https://cloud.mobify.com',
            projectSlug: 'test-project',
            auth: 'test@mobify.com:asdf1234',
            dataLength: 1024
        };

        var expectedPath = '/api/projects/' + opts.projectSlug + '/builds/';

        var request = Utils.buildRequest(opts, test.done);

        test.equal(request.uri.origin, opts.host);
        test.equal(request.uri.path, expectedPath);
        test.equal(request.method, 'POST');

        test.done();
    },

    buildRequestForTarget: function(test) {
        var opts = {
            origin: 'https://cloud.mobify.com',
            projectSlug: 'test-project',
            auth: 'test@mobify.com:asdf1234',
            target: 'staging',
            dataLength: 1024
        };

        var expectedPath = '/api/projects/' + opts.projectSlug + '/builds/' + opts.target + '/';

        var request = Utils.buildRequest(opts, test.done);

        test.equal(request.uri.origin, opts.host);
        test.equal(request.uri.path, expectedPath);
        test.equal(request.method, 'POST');

        test.done();
    }
};
